from fastapi import FastAPI
from app.routers import upload
from app.routers import chat_gemini_router, crm_router
from app.routers import calendar_router




app = FastAPI(title="Multi-Agentic Conversational AI System")

#app.include_router(chat.router, prefix="/chat") --> dont use it
app.include_router(upload.router, prefix="/upload_docs")
#app.include_router(crm.router, prefix="/crm") --> don't use it
app.include_router(chat_gemini_router.router)
#app.include_router(chat_voice_router.router) -> don't use it
app.include_router(crm_router.router)
app.include_router(calendar_router.router)

@app.get("/")
def root():
    return {"message": "Multi-Agentic Conversational AI System is running!"}
