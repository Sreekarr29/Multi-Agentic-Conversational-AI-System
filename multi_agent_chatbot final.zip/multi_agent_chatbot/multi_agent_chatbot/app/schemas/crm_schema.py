from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime

class UserCreate(BaseModel):
    user_id: str
    name: Optional[str] = None
    email: Optional[EmailStr] = None
    company: Optional[str] = None
    location: Optional[str]
    preferences: Optional[str] = None


class UserUpdate(BaseModel):
    name: Optional[str] = None
    email: Optional[EmailStr] = None
    company: Optional[str] = None
    location: Optional[str] = None
    preferences: Optional[str] = None

class ChatMessage(BaseModel):
    user_id: str
    message: str
    response: str
    timestamp: datetime
    tags: Optional[List[str]] = []
    status: Optional[str] = "inquiry" 

class UpdateTagsRequest(BaseModel):
    tags: Optional[List[str]] = None
    status: Optional[str] = None

class GeminiChatRequest(BaseModel):
    user_id: Optional[str] = None
    message: str

class CalendarEvent(BaseModel):
    user_id: str
    title: str
    start_time: datetime
    end_time: datetime
    description: Optional[str] = None