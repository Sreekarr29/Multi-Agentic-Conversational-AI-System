from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class CalendarEventCreate(BaseModel):
    user_id: str
    title: str
    description: Optional[str] = None
    datetime: datetime
    conversation_id: Optional[str] = None

class CalendarEventUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    datetime: Optional[datetime] = None

