import requests
import json
import os

# Set your Gemini API key
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

# Use the right model endpoint (choose pro or flash)
GEMINI_MODEL = "gemini-1.5-pro-latest"
API_URL = f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent?key={GEMINI_API_KEY}"

def ask_gemini(prompt: str, context: str = "") -> str:
    # Construct request payload
    payload = {
        "contents": [
            {
                "parts": [
                    {"text": f"{context}\n\n{prompt}"}
                ]
            }
        ]
    }

    headers = {"Content-Type": "application/json"}

    # Make the request
    response = requests.post(API_URL, headers=headers, data=json.dumps(payload))

    # Check response
    if response.status_code == 200:
        res_json = response.json()
        try:
            return res_json["candidates"][0]["content"]["parts"][0]["text"]
        except (KeyError, IndexError):
            return "Gemini Error: 'candidates' key missing or malformed."
    else:
        return f"Gemini Error: {response.text}"
    
def check_scope_with_context(prompt: str, context: str) -> bool:
    check_prompt = f"""
You are a smart assistant helping users based only on the company's internal data.

CONTEXT:
{context}

USER QUESTION:
{prompt}

Does the context contain enough information to answer the user's question?
Respond with just "Yes" or "No".
"""

    result = ask_gemini(check_prompt)
    return "yes" in result.lower()

def analyze_intent(message: str) -> str:
    prompt = f"""
You are a message classifier. Determine the intent of this message:
"{message}"

Possible intents:
- greeting
- schedule
- meeting
- event
- rent_question
- unrelated
- farewell
- smalltalk

Respond with just the intent label (like: greeting)
"""

    intent = ask_gemini(prompt).strip().lower()
    return intent

# Example usage
if __name__ == "__main__":
    context = "1412 Broadway | $2,109,184 Annual Rent | Floor P4"
    question = "What is the annual rent for 1412 Broadway?"
    print(ask_gemini(question, context))
