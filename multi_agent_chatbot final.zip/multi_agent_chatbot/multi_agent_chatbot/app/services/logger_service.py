# app/services/logger_service.py

from datetime import datetime
from app.services.mongodb import conversations_collection  # using your existing import

def log_conversation(user_id: str, message: str, response: str):
    conversations_collection.insert_one({
        "user_id": user_id,
        "message": message,
        "response": response,
        "timestamp": datetime.utcnow()
    })
