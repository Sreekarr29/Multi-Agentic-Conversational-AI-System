from pymongo import MongoClient
import os

# You can load this from a .env file instead
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")

client = MongoClient(MONGO_URI)
db = client["multi_agent_crm"]
users_collection = db["users"]
conversations_collection = db["conversations"]
calendar_collection = db["calendar"]