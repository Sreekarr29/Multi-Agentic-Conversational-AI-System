import os
import pandas as pd
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import FAISS
from langchain.text_splitter import CharacterTextSplitter
from langchain.document_loaders import PyPDFLoader, TextLoader
from dotenv import load_dotenv
from langchain.schema import Document

load_dotenv()

DATA_DIR = "rag_data"
os.makedirs(DATA_DIR, exist_ok=True)

embeddings = OpenAIEmbeddings(openai_api_key=os.getenv("OPENAI_API_KEY"))

def process_and_store(file_path: str):
    # Load documents based on file type
    if file_path.endswith(".pdf"):
        loader = PyPDFLoader(file_path)
        documents = loader.load()
    elif file_path.endswith(".txt"):
        loader = TextLoader(file_path)
        documents = loader.load()
    elif file_path.endswith(".csv"):
        df = pd.read_csv(file_path)
        # Combine each row into a text block
        documents = [Document(page_content=" | ".join(str(val) for val in row.values)) for _, row in df.iterrows()]
    else:
        raise ValueError("Unsupported file type.")

    # Split and store
    text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
    chunks = text_splitter.split_documents(documents)

    db = FAISS.from_documents(chunks, embeddings)
    db.save_local(DATA_DIR)

def get_context(question: str):
    if not os.path.exists(DATA_DIR):
        return ""

    db = FAISS.load_local(DATA_DIR, embeddings, allow_dangerous_deserialization=True)
    docs = db.similarity_search(question, k=100)
    return "\n\n".join(doc.page_content for doc in docs)
