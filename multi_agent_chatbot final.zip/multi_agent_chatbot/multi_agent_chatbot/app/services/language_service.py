from deep_translator import GoogleTranslator
from langdetect import detect

def detect_language(text: str) -> str:
    try:
        return detect(text)
    except:
        return "en"

def translate_to_english(text: str) -> str:
    try:
        return GoogleTranslator(source='auto', target='en').translate(text)
    except:
        return text

def translate_from_english(text: str, dest_lang: str) -> str:
    if dest_lang == "en":
        return text
    try:
        return GoogleTranslator(source='en', target=dest_lang).translate(text)
    except:
        return text
