
import os
from dotenv import load_dotenv
from pymongo import MongoClient
from datetime import datetime

load_dotenv()

client = MongoClient(os.getenv("MONGO_URI"))
db = client[os.getenv("MONGO_DB_NAME")]
users_col = db["users"]
conversations_col = db["conversations"]

def create_user(user_data):
    user_data["created_at"] = datetime.utcnow()
    result = users_col.insert_one(user_data)
    return str(result.inserted_id)

def update_user(user_id, update_data):
    result = users_col.update_one({"_id": user_id}, {"$set": update_data})
    return result.modified_count

def log_conversation(user_id, message, response, tags=None):
    record = {
        "user_id": user_id,
        "message": message,
        "response": response,
        "tags": tags or [],
        "timestamp": datetime.utcnow()
    }
    conversations_col.insert_one(record)

def get_conversations(user_id):
    return list(conversations_col.find({"user_id": user_id}))
