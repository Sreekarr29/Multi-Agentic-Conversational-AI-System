from app.schemas.crm_schema import CalendarEvent
from datetime import datetime, timedelta
from uuid import uuid4
from app.services.gemini_service import ask_gemini  # use lightweight Gemini wrapper
from app.services.mongodb import calendar_collection
import json
import re

def extract_calendar_event(user_id: str, message: str) -> CalendarEvent | None:
    prompt = f"""
You are a smart assistant that detects if the user's message is about scheduling a calendar event.

Message: "{message}"

If this message is requesting to schedule something, respond in this JSON format:
{{
  "title": "Short description of the event",
  "start_time": "2025-07-13T14:00:00",
  "end_time": "2025-07-13T15:00:00",
  "description": "Optional long message"
}}

If there's no event to schedule, reply with:
{{ "title": null }}
"""
    try:
        raw = ask_gemini(prompt)

        # 🧹 Strip code fences and language hint
        cleaned = re.sub(r"^```json|```$", "", raw.strip(), flags=re.MULTILINE).strip()

        # ✅ Use json.loads instead of eval
        data = json.loads(cleaned)

        if not data.get("title"):
            return None

        return CalendarEvent(
            user_id=user_id,
            title=data["title"],
            start_time=datetime.fromisoformat(data["start_time"]),
            end_time=datetime.fromisoformat(data["end_time"]),
            description=data.get("description", message)
        )

    except Exception as e:
        print("Calendar intent extraction failed:", e)
        return None
    
def has_conflict(user_id: str, start_time: datetime, end_time: datetime) -> dict | None:
    conflict = calendar_collection.find_one({
        "user_id": user_id,
        "start_time": {"$lt": end_time},
        "end_time": {"$gt": start_time}
    })
    return conflict  # will return the event dict if exists