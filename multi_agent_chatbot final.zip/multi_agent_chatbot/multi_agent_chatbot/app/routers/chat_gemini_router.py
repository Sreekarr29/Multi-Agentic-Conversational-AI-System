from fastapi import APIRouter
from pydantic import BaseModel
from app.services.gemini_service import ask_gemini, check_scope_with_context, analyze_intent
from app.services.rag_service import get_context
from app.services.logger_service import log_conversation
from app.services.mongodb import users_collection, conversations_collection, calendar_collection
from app.schemas.crm_schema import GeminiChatRequest
from app.services.calendar_service import extract_calendar_event, has_conflict
from app.services.language_service import detect_language, translate_to_english, translate_from_english
from datetime import datetime
from uuid import uuid4
import time

router = APIRouter()

def generate_tags(message: str) -> list:
    keywords = {
        "rent": ["rent", "lease", "price", "cost"],
        "property": ["broadway", "building", "address"],
        "contact": ["email", "contact", "phone", "call"],
        "calender": ["meeting", "scheduling", "schedule", "event"],
        "status": ["available", "vacant", "occupied"]
    }
    tags = set()
    for tag, words in keywords.items():
        for word in words:
            if word in message.lower():
                tags.add(tag)
    return list(tags)

@router.post("/chat/gemini")
def gemini_chat_endpoint(request: GeminiChatRequest):
    start_time = time.time()
    from app.services.calendar_service import has_conflict  # for conflict detection

    # Step 1: Handle guest user
    if not request.user_id:
        generated_id = f"guest-{str(uuid4())}"
        request.user_id = generated_id
        users_collection.insert_one({
            "user_id": generated_id,
            "name": "Guest User",
            "email": None,
            "location": None,
            "preferences": None,
            "created_at": datetime.utcnow(),
            "is_guest": True
        })
    else:
        generated_id = request.user_id

    # 🌐 Step 1.5: Detect and translate if non-English
    original_language = detect_language(request.message)
    translated_message = request.message
    if len(request.message.strip()) <= 6:
        original_language = "en"
    if original_language != "en":
            translated_message = translate_to_english(request.message)

    # 🧠 Step 2: NLP intent classification
    intent = analyze_intent(translated_message)

    if intent == "greeting":
        response_text = "Hello! How can I assist you with any rent or property-related queries today?"
        if original_language != "en":
            response_text = translate_from_english(response_text, original_language)
        return {
            "user_id": request.user_id,
            "guest_reference": generated_id if "guest-" in request.user_id else None,
            "conversation_id": None,
            "response": response_text,
            "used_context": "",
            "tags": ["greeting"],
            "calendar_event_id": None
        }

    if intent == "unrelated":
        response_text = "I'm here to help with rent, leases, properties, and internal queries. Let me know how I can assist!"
        if original_language != "en":
            response_text = translate_from_english(response_text, original_language)
        return {
            "user_id": request.user_id,
            "guest_reference": generated_id if "guest-" in request.user_id else None,
            "conversation_id": None,
            "response": response_text,
            "used_context": "",
            "tags": ["unrelated"],
            "calendar_event_id": None
        }

    # Step 3: Check for calendar intent FIRST
    calendar_event = extract_calendar_event(request.user_id, request.message)
    calendar_event_id = None
    conversation_id = str(uuid4())

    if calendar_event:
        conflict = has_conflict(request.user_id, calendar_event.start_time, calendar_event.end_time)
        if conflict:
            conflict_msg = f"⚠️ You already have a scheduled event at that time: **{conflict['title']}**.\nReference ID: `{conflict['event_id']}`"
            # 🌐 Translate if needed
            if original_language != "en":
                conflict_msg = translate_from_english(conflict_msg, original_language)

            return {
                "user_id": request.user_id,
                "guest_reference": generated_id if "guest-" in request.user_id else None,
                "conversation_id": None,
                "response": conflict_msg,
                "used_context": "",
                "tags": ["calendar", "conflict"],
                "calendar_event_id": conflict["event_id"]
            }

        calendar_event_id = str(uuid4())
        calendar_collection.insert_one({
            **calendar_event.dict(),
            "event_id": calendar_event_id,
            "user_id": request.user_id,
            "conversation_id": conversation_id,
            "created_at": datetime.utcnow()
        })
        response = f"✅ Event scheduled: **{calendar_event.title}** from {calendar_event.start_time} to {calendar_event.end_time}. Event ID: `{calendar_event_id}`"
        if original_language != "en":
            response = translate_from_english(response, original_language)

        conversations_collection.insert_one({
            "conversation_id": conversation_id,
            "user_id": request.user_id,
            "message": request.message,
            "response": response,
            "timestamp": datetime.utcnow(),
            "tags": ["calendar"],
            "status": "inquiry"
        })

        return {
            "user_id": request.user_id,
            "guest_reference": generated_id if "guest-" in request.user_id else None,
            "conversation_id": conversation_id,
            "response": response,
            "used_context": "",
            "tags": ["calendar"],
            "calendar_event_id": calendar_event_id
        }

    # Step 4: Normal RAG flow
    context = get_context(translated_message)
    if not check_scope_with_context(request.message, context):
        fallback_response = "I'm designed to assist only with your organization's data — such as rent, CRM, or scheduling. Please rephrase your question accordingly."
        if original_language != "en":
            fallback_response = translate_from_english(fallback_response, original_language)
        return {
            "user_id": request.user_id,
            "guest_reference": generated_id if "guest-" in generated_id else None,
            "conversation_id": None,
            "response": fallback_response,
            "used_context": context[:1000],
            "tags": ["out-of-scope"],
            "calendar_event_id": None
        }

    response = ask_gemini(translated_message, context)
    tags = generate_tags(request.message)

    end_time = time.time()
    duration_ms = round((end_time - start_time) * 1000)  # response time in milliseconds

    conversations_collection.insert_one({
        "conversation_id": conversation_id,
        "user_id": request.user_id,
        "message": request.message,
        "response": response,
        "timestamp": datetime.utcnow(),
        "tags": tags,
        "response_time_ms": duration_ms ,
        "status": "inquiry"
    })


    return {
        "user_id": request.user_id,
        "guest_reference": generated_id if "guest-" in generated_id else None,
        "conversation_id": conversation_id,
        "response": response,
        "used_context": context[:1000],
        "tags": tags,
        "intent": intent,
        "calendar_event_id": None,
        "response_time_ms": duration_ms 
    }
