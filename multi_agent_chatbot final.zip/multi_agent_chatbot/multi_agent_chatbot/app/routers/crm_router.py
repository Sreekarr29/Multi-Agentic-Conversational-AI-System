from fastapi import APIRouter, HTTPException
from app.services.mongodb import users_collection, conversations_collection
from app.schemas.crm_schema import UserCreate, UserUpdate, UpdateTagsRequest
from datetime import datetime
from pymongo import MongoClient
from typing import Optional, List
from pydantic import BaseModel
import os

router = APIRouter()

# MongoDB setup
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
client = MongoClient(MONGO_URI)
db = client["multi_agent_crm"]
conversations_collection = db["conversations"]

class UpdateTagsRequest(BaseModel):
    tags: Optional[List[str]] = []
    status: Optional[str] = None

class ResetRequest(BaseModel):
    user_id: str

@router.post("/create_user")
def create_user(user: UserCreate):
    if users_collection.find_one({"user_id": user.user_id}):
        raise HTTPException(status_code=400, detail="User already exists")
    users_collection.insert_one(user.dict())
    return {"message": "User created"}

@router.get("/conversations/{user_id}")
def get_user_conversations(user_id: str):
    print(f"Querying for user_id: '{user_id}'")

    chats_cursor = conversations_collection.find({"user_id": user_id}, {"_id": 0})
    chats = list(chats_cursor)

    print("Fetched conversations:", chats)

    return {
        "user_id": user_id,
        "conversations": chats
    }

@router.get("/conversations/{user_id}/filtered")
def get_filtered_conversations(user_id: str, tag: Optional[str] = None, status: Optional[str] = None):
    query = {"user_id": user_id}
    if tag:
        query["tags"] = tag
    if status:
        query["status"] = status

    chats = list(conversations_collection.find(query, {"_id": 0}).sort("timestamp", -1))
    return {"user_id": user_id, "filtered_conversations": chats}

@router.put("/conversations/{user_id}/update_tag/{conversation_id}")
def update_conversation_tags(user_id: str, conversation_id: str, update: UpdateTagsRequest):
    query = {
        "user_id": user_id,
        "conversation_id": conversation_id
    }

    update_doc = {}
    if update.tags is not None:
        update_doc["tags"] = update.tags
    if update.status is not None:
        update_doc["status"] = update.status

    if not update_doc:
        raise HTTPException(status_code=400, detail="No tags or status to update")

    result = conversations_collection.update_one(query, {"$set": update_doc})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Conversation not found for this user")

    return {"message": "Conversation updated", "updated_fields": update_doc}

@router.put("/update_user/{user_id}")
def update_user(user_id: str, update: UserUpdate):
    result = users_collection.update_one(
        {"user_id": user_id}, {"$set": update.dict(exclude_unset=True)}
    )
    if result.modified_count == 0:
        raise HTTPException(status_code=404, detail="User not found or nothing updated")
    return {"message": "User updated"}

@router.post("/reset")
def reset_user_conversations(req: ResetRequest):
    result = conversations_collection.delete_many({"user_id": req.user_id})
    return {
        "message": f"Deleted {result.deleted_count} conversations for user {req.user_id}"
    }