from fastapi import APIRouter, File, UploadFile
import shutil
import os
from app.services.rag_service import process_and_store

router = APIRouter()

@router.post("/")
def upload_doc(file: UploadFile = File(...)):
    save_path = os.path.join("uploads", file.filename)
    os.makedirs("uploads", exist_ok=True)
    
    with open(save_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    process_and_store(save_path)
    return {"message": "File uploaded and processed successfully"}
