from fastapi import APIRouter, HTTPException
from uuid import uuid4
from datetime import datetime
from app.schemas.calendar_schema import CalendarEventCreate, CalendarEventUpdate
from app.services.mongodb import db
from app.schemas.crm_schema import CalendarEvent

router = APIRouter(prefix="/calendar", tags=["Calendar"])

calendar_collection = db["calendar"]

@router.post("/create_event")
def create_event(event: CalendarEventCreate):
    event_id = str(uuid4())
    calendar_collection.insert_one({
        "event_id": event_id,
        "user_id": event.user_id,
        "title": event.title,
        "description": event.description,
        "datetime": event.datetime,
        "conversation_id": event.conversation_id,
        "created_at": datetime.utcnow()
    })
    return {"message": "Event created", "event_id": event_id}

@router.get("/user/{user_id}")
def get_events(user_id: str):
    events = list(calendar_collection.find({"user_id": user_id}, {"_id": 0}))
    return {"events": events}

@router.put("/update/{event_id}")
def update_event(event_id: str, update: CalendarEventUpdate):
    update_doc = {k: v for k, v in update.dict().items() if v is not None}
    if not update_doc:
        raise HTTPException(status_code=400, detail="No fields to update")
    result = calendar_collection.update_one({"event_id": event_id}, {"$set": update_doc})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Event not found")
    return {"message": "Event updated"}

@router.delete("/delete/{event_id}")
def delete_event(event_id: str):
    result = calendar_collection.delete_one({"event_id": event_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Event not found")
    return {"message": "Event deleted"}

@router.get("/calendar/{user_id}")
def get_user_events(user_id: str):
    events = list(calendar_collection.find({"user_id": user_id}, {"_id": 0}))
    return {"user_id": user_id, "events": events}

@router.post("/calendar/create")
def create_calendar_event(event: CalendarEvent):
    event_id = str(uuid4())
    calendar_collection.insert_one({**event.dict(), "event_id": event_id, "created_at": datetime.utcnow()})
    return {"message": "Event scheduled", "event_id": event_id}
